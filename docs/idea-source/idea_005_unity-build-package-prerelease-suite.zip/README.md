# Build・Package・販売前リリーススイート 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | UnityEditor |
| No. | 5 |
| 分野 | ビルド・販売前確認 |
| アイデア | Build・Package・販売前リリーススイート |
| リポジトリ名 | unity-build-package-prerelease-suite |
| 概要 | Build、Package、Release、Asset Store、BOOTH販売前チェックをまとめる。 |
| 課題 | 公開前に形式、依存、サンプル、説明、販売用素材を別々に確認する必要がある。 |
| 類似サービス・アプリ | Unity Package Manager, Asset Store Tools, GitHub Releases |
| 差別化ポイント | Unity内のビルド確認と販売前検品を同じリリース導線にする。 |

## 目的

このZIPには、`UnityEditor` 領域のアイデア `Build・Package・販売前リリーススイート` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
