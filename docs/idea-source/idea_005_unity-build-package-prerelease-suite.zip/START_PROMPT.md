あなたはこのアイデアの実装担当エージェントです。要件定義、仕様、設計、MVP実装、検証まで、この開発パックに沿って進めてください。

## 対象アイデア

- 親分類: Plugins
- 領域: UnityEditor
- No.: 5
- 分野: ビルド・販売前確認
- アイデア: Build・Package・販売前リリーススイート
- リポジトリ名: unity-build-package-prerelease-suite

## 元アイデア

- 概要: Build、Package、Release、Asset Store、BOOTH販売前チェックをまとめる。
- 課題: 公開前に形式、依存、サンプル、説明、販売用素材を別々に確認する必要がある。
- 類似サービス・アプリ: Unity Package Manager, Asset Store Tools, GitHub Releases
- 差別化ポイント: Unity内のビルド確認と販売前検品を同じリリース導線にする。

## 最初に行うこと

1. このZIP内の `01_REQUIREMENTS.md`、`02_SPECIFICATION.md`、`03_DESIGN.md` を読む。
2. 実装前に未決事項を洗い出す。
3. 既存リポジトリがある場合は、先に README、docs、Issue、テスト、現在のアーキテクチャを確認する。
4. 新規リポジトリの場合は、`04_IMPLEMENTATION_PLAN.md` のMVPから開始する。
5. 実装前に、プラットフォーム、保存方式、主要ユーザーフロー、検証方法を明記する。

## 領域別の重点事項

- ホストアプリのバージョン、権限、パネル/メニュー導線、ファイル入出力境界を明確にする。
- ホストアプリのデータモデル、選択状態、書き出しパイプライン、失敗パターンを前提に設計する。
- サンプルプロジェクトと実際のホストアプリ操作で検証する。

## Done Means

- The MVP works.
- The main flow has been manually verified.
- Test or verification steps are repeatable.
- README or usage notes are updated.
- Remaining work is captured in release checklist or issues.
